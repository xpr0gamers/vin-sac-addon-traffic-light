(function(){"use strict";class n extends HTMLElement{setExtensionData(e){debugger}onBeforeUpdate(e){}onAfterUpdate(e){}render(){debugger}}customElements.define("viz-plotarea-general",n)})();
